<!DOCTYPE html>
<html>

  <head>

    <title></title>
    <style>


      nav {
        float: right;
      }


      
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }




      li {
        display: inline-block;
        margin-right: 10px;
      }

      
    </style>
  </head>
  <body>
    <header>
      <nav>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="Login.php">Login</a></li>
          <li><a href="#">Registration</a></li>
        </ul>
      </nav>
    </header>
    <br>
    <hr>
  </body>
</html>
